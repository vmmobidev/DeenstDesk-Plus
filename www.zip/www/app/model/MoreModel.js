/* Description: SelectImpact Model
* Created On: May 15th 2012
* Created By: Ram
* Last Modified On: 
* Last Modified By:Nikhil
* Last Modified Reason: Added Header and comments
* TODO:
*/
Ext.define("DDLApp.model.MoreModel", {
    extend: "Ext.data.Model",
    config: {
        fields: ['name']
    }
});